package com.example.weather_app_youtube

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
